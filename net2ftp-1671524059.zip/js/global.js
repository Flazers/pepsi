var json = function (response) {
    return response.json();
}

var base_URL = "http://127.0.0.1:8000/";

var month = [
    'Янв',
    'Фев',
    'Мар',
    'Апр',
    'Мая',
    'Июн',
    'Июл',
    'Авг',
    'Сен',
    'Окт',
    'Ноя',
    'Дек'
];


async function onloads() {
    if (localStorage.getItem('token') !== null) {
        document.querySelector('span.login').remove();
        document.querySelector('span.login1').remove();
    } else {
        document.querySelector('a#my').remove();
        document.querySelector('a#my').remove();

        let dele = document.querySelector('div.dropdown');
        while (dele.firstChild) {
            dele.removeChild(dele.firstChild);
        }
        dele.remove(dele)

        let delet = document.querySelector('div.dropdown');
        while (delet.firstChild) {
            delet.removeChild(delet.firstChild);
        }
        delet.remove(delet)

    }
}

var noauth_401 = function (message) {
    if (localStorage.getItem('token') == null) {

        let del = document.querySelector('div.inGet')
        del.remove()

        let body = document.querySelector('div.body')
        let inNo = document.createElement('div')
        inNo.className = 'inNo f'
        inNo.innerHTML = message
        body.appendChild(inNo)
    }
}

//ВЫХОД
var logout = function () {
    fetch('http://127.0.0.1:8000/api/logout', {
        method: 'DELETE',
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
    })
        .then(function () {
            localStorage.removeItem('user');
            localStorage.removeItem('id');
            localStorage.removeItem('token');
            window.location.href = '/';
        })
}