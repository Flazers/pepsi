onloads()
//Все посты авторизированного пользователя
async function AllMyPost() {
    const res = await fetch(base_URL + "api/showpost/" + localStorage.getItem('user'), {
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
    })
    const data = await res.json();
    if (data.posts.length !== 0) {
        var datapost = data.posts.reverse();
        for (i in datapost) {
            let getfor = document.querySelector('div.inGet')
            let div = document.createElement('div');
            div.className = 'post';
            div.id = i;
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let getfor = document.getElementById(a)
            let div = document.createElement('div');
            div.className = 'postheader';
            div.id = 'postheader' + a
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let getfor = document.getElementById('postheader' + a)
            let div = document.createElement('div');
            div.id = 'div' + a
            div.className = 'f'
            getfor.appendChild(div);
        }

        for (d in datapost) {
            if (data.avatar !== null) {
                let getfor = document.getElementById('div' + d)
                let img = document.createElement('img');
                img.id = 'avatarpost';
                img.src = "http://127.0.0.1:8000/storage/" + data.avatar;
                getfor.appendChild(img);
            } else {
                let getfor = document.getElementById('div' + d)
                let img = document.createElement('img');
                img.id = 'avatarpost';
                img.src = "http://127.0.0.1:8000/storage/avatar/zagl.png";
                getfor.appendChild(img);
            }
        }

        for (d in datapost) {
            let getfor = document.getElementById('div' + d)
            let div = document.createElement('div');
            div.id = 'authorpost';
            div.innerHTML = datapost[d]["user_id"]
            getfor.appendChild(div);
        }

        for (s in datapost) {
            let getfor = document.getElementById(s)
            let form = document.createElement('form');
            form.id = 'post' + datapost[s]["id"]
            form.className = 'postr' + datapost[s]["id"]
            form.onsubmit = function () { event.preventDefault(); }
            getfor.appendChild(form);
        }

        for (s in datapost) {
            let getfor = document.getElementById('post' + datapost[s]["id"])
            let div = document.createElement('div');
            div.className = 'titlepost';
            div.id = 't' + datapost[s]["id"]
            div.innerHTML = datapost[s]["title"]
            getfor.appendChild(div);
        }

        for (s in datapost) {
            let getfor = document.getElementById('post' + datapost[s]["id"])
            let div = document.createElement('div');
            div.className = 'contentpost';
            div.id = 'c' + datapost[s]["id"]
            div.innerHTML = datapost[s]["content"]
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let getfor = document.getElementById('postheader' + a)
            let div = document.createElement('div');
            div.className = 'menu-post-t';
            div.id = 'menu-post-t' + a
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let blockdrop = document.querySelector('div#menu-post-t' + a)
            let img = document.createElement('img')
            img.className = 'menu-post-';
            img.src = "http://127.0.0.1:8000/storage/system/more.svg"
            blockdrop.appendChild(img);
        }

        for (a in datapost) {
            let blockdrop = document.querySelector('div#menu-post-t' + a)
            let div = document.createElement('div')
            div.id = 'menu-post-c' + a
            div.className = 'menu-post-t-content ' + a
            blockdrop.appendChild(div);
        }

        for (a in datapost) {
            let blockdrop = document.querySelector('div#menu-post-c' + a)
            let button = document.createElement('button')
            button.innerHTML = 'Редактировать'
            button.id = datapost[a]["id"]
            button.onclick = function () {
                let dele = document.getElementById('t' + this.id);
                let inp = document.createElement('input')
                inp.className = 'titlepost'
                inp.name = 'title'
                inp.id = 'title' + this.id
                inp.value = document.getElementById('t' + this.id).innerHTML
                dele.parentNode.replaceChild(inp, dele)

                let delet = document.getElementById('c' + this.id);
                let inp1 = document.createElement('input')
                inp1.className = 'contentpost'
                inp1.name = 'content'
                inp1.id = 'content' + this.id
                inp1.value = document.getElementById('c' + this.id).innerHTML
                delet.parentNode.replaceChild(inp1, delet)

                let ids = this.id
                let titles1 = document.getElementById('title' + this.id)
                let contents1 = document.getElementById('content' + this.id)

                let getfor = document.querySelector('form.postr' + this.id)
                let button = document.createElement('button');
                button.onclick = function () {
                    let titles = titles1.value
                    let contents = contents1.value
                    fetch(base_URL + 'api/redpost/' + ids, {
                        method: 'PUT',
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + localStorage.getItem('token')
                        },
                        body: JSON.stringify({
                            title: titles,
                            content: contents
                        })
                    })
                        .then(function (response) {
                            if (response.status == 200) {
                                window.location.href = '/myposts.html'
                            } else {
                                alert('Ошибка')
                            }
                        })
                        .then(json)

                }
                button.innerHTML = 'Сохранить'
                getfor.appendChild(button);
            }
            blockdrop.appendChild(button);
        }

        for (a in datapost) {
            let blockdrop = document.querySelector('div#menu-post-c' + a)
            let button = document.createElement('button')
            button.id = datapost[a]["id"]
            button.innerHTML = 'Удалить'
            button.onclick = function () {
                fetch(base_URL + 'api/deletepost/' + this.id, {
                    method: "DELETE",
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('token')
                    },
                })
                    .then(json)
                    .then(function () {
                        window.location.href = "myposts.html"
                    })
            }
            blockdrop.appendChild(button);
        }

        for (s in datapost) {
            let getfor = document.getElementById(s)
            let div = document.createElement('div');
            let time = new Date(data.posts[s].created_at);
            let newDate =
                time.getHours().toString() + ":" + (time.getMinutes() < 10 ? '0' : '') + time.getMinutes() + ", " +
                time.getDate().toString() + " " + month[time.getMonth()] + ", " + time.getFullYear().toString()
            div.id = 'datapost';
            div.innerHTML = newDate;
            getfor.appendChild(div);
        }
    } else {
        let getfor = document.querySelector('div.inGet')
        let div = document.createElement('div');
        div.className = "inNo f"
        div.innerHTML = 'У вас нет постов'
        getfor.appendChild(div);
    }
}

//Все посты
async function AllPosts() {
    const res = await fetch(base_URL + "api/showpost")
    const data = await res.json();
    var datapost = data.posts.reverse()
    for (i in datapost) {
        let getfor = document.querySelector('div.inGet')
        let div = document.createElement('div');
        div.className = 'post';
        div.id = i;
        getfor.appendChild(div);
    }

    for (a in datapost) {
        let getfor = document.getElementById(a)
        let div = document.createElement('div');
        div.className = 'postheader';
        div.id = 'postheader' + a
        getfor.appendChild(div);
    }

    for (a in datapost) {
        let getfor = document.getElementById('postheader' + a)
        let div = document.createElement('div');
        div.id = 'div' + a
        div.className = 'f'
        getfor.appendChild(div);
    }

    for (d in datapost) {
        if (datapost[d]['avatar']['avatar'] !== null) {
            let getfor = document.getElementById('div' + d)
            let img = document.createElement('img');
            img.id = 'avatarpost';
            img.src = "http://127.0.0.1:8000/storage/" + datapost[d]['avatar']['avatar'];
            getfor.appendChild(img);
        } else {
            let getfor = document.getElementById('div' + d)
            let img = document.createElement('img');
            img.id = 'avatarpost';
            img.src = "http://127.0.0.1:8000/storage/avatar/zagl.png";
            getfor.appendChild(img);
        }
    }
    for (d in datapost) {
        let getfor = document.getElementById('div' + d)
        let div = document.createElement('div');
        div.id = 'authorpost';
        div.innerHTML = datapost[d]["user_id"]
        getfor.appendChild(div);
    }
    for (s in datapost) {
        let getfor = document.getElementById(s)
        let div = document.createElement('div');
        div.className = 'titlepost';
        div.innerHTML = datapost[s]["title"]
        getfor.appendChild(div);
    }
    for (s in datapost) {
        let getfor = document.getElementById(s)
        let div = document.createElement('div');
        div.className = 'contentpost';
        div.innerHTML = datapost[s]["content"]
        getfor.appendChild(div);
    }

    for (s in datapost) {
        let getfor = document.getElementById(s)
        let div = document.createElement('div');
        let time = new Date(data.posts[s].created_at);
        let newDate =
            time.getHours().toString() + ":" + (time.getMinutes() < 10 ? '0' : '') + time.getMinutes() + ", " +
            time.getDate().toString() + " " + month[time.getMonth()] + ", " + time.getFullYear().toString()
        div.id = 'datapost';
        div.innerHTML = newDate;
        getfor.appendChild(div);
    }
}

//функции query 
async function searchf() {
    let querystring = document.getElementById('searchh').value
    sessionStorage.setItem('query', querystring)
    window.location.href = '/search.html'
}

async function searchstring() {
    const res = await fetch(base_URL + 'api/showpost?query=' + sessionStorage.getItem('query'))
    const data = await res.json();
    if (data.posts.length > 0) {
        var datapost = data.posts.reverse()
        for (i in datapost) {
            let getfor = document.querySelector('div.inGet')
            let div = document.createElement('div');
            div.className = 'post';
            div.id = i;
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let getfor = document.getElementById(a)
            let div = document.createElement('div');
            div.className = 'postheader';
            div.id = 'postheader' + a
            getfor.appendChild(div);
        }

        for (a in datapost) {
            let getfor = document.getElementById('postheader' + a)
            let div = document.createElement('div');
            div.id = 'div' + a
            div.className = 'f'
            getfor.appendChild(div);
        }

        for (d in datapost) {
            if (datapost[d]['avatar']['avatar'] !== null) {
                let getfor = document.getElementById('div' + d)
                let img = document.createElement('img');
                img.id = 'avatarpost';
                img.src = "http://127.0.0.1:8000/storage/" + datapost[d]['avatar']['avatar'];
                getfor.appendChild(img);
            } else {
                let getfor = document.getElementById('div' + d)
                let img = document.createElement('img');
                img.id = 'avatarpost';
                img.src = "http://127.0.0.1:8000/storage/avatar/zagl.png";
                getfor.appendChild(img);
            }
        }
        for (d in datapost) {
            let getfor = document.getElementById('div' + d)
            let div = document.createElement('div');
            div.id = 'authorpost';
            div.innerHTML = datapost[d]["user_id"]
            getfor.appendChild(div);
        }
        for (s in datapost) {
            let getfor = document.getElementById(s)
            let div = document.createElement('div');
            div.className = 'titlepost';
            div.innerHTML = datapost[s]["title"]
            getfor.appendChild(div);
        }
        for (s in datapost) {
            let getfor = document.getElementById(s)
            let div = document.createElement('div');
            div.className = 'contentpost';
            div.innerHTML = datapost[s]["content"]
            getfor.appendChild(div);
        }

        for (s in datapost) {
            let getfor = document.getElementById(s)
            let div = document.createElement('div');
            let time = new Date(data.posts[s].created_at);
            let newDate =
                time.getHours().toString() + ":" + (time.getMinutes() < 10 ? '0' : '') + time.getMinutes() + ", " +
                time.getDate().toString() + " " + month[time.getMonth()] + ", " + time.getFullYear().toString()
            div.id = 'datapost';
            div.innerHTML = newDate;
            getfor.appendChild(div);
        }
    } else {
        let body = document.querySelector('div.body')
        let inNo = document.createElement('div')
        inNo.className = 'inNo f'
        inNo.innerHTML = 'Таких постов не существует'
        body.appendChild(inNo)
    }
}