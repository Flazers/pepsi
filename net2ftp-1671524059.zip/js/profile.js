onloads()
//Получение информации с сервера
async function getProfileInfo() {
    const res = await fetch(base_URL + `api/users/` + localStorage.getItem('user'))
        .then(json)
        .then(function (response) {
            let resp1 = document.getElementById('pst_avaprofile');
            let ava = document.createElement('img');
            let bk = document.getElementById('avaform')
            if (response.data[0]["avatar"] !== null) {
                ava.src = "http://127.0.0.1:8000/storage/" + response.data[0]["avatar"];
            } else {
                ava.src = "http://127.0.0.1:8000/storage/avatar/zagl.png";
            }
            resp1.insertBefore(ava, bk)

            let resp = document.getElementById('pst_profile');

            let pbl = document.createElement('p');
            if (response.data[0]["first_name"] == null || response.data[0]["last_name"] == null) {
                pbl.innerHTML = response.data[0]["user_id"];
            } else {
                pbl.innerHTML = response.data[0]["first_name"] + " " + response.data[0]["last_name"] + " (" + response.data[0]["user_id"] + ")";
            }
            resp.appendChild(pbl);

            let line = document.createElement('br')
            resp.appendChild(line);

            let pbl1 = document.createElement('p');
            if (response.data[0]["gender"] == null) {
                pbl1.innerHTML = "Пол: не указан"
            } else {
                pbl1.innerHTML = "Пол: " + response.data[0]["gender"]
            }
            resp.appendChild(pbl1);
            let birth = new Date(response.data[0]["birthday"])
            let birth2 = birth.getDate().toString() + " " + month[birth.getMonth()] + ", " + birth.getFullYear().toString() + "г."

            let phone = document.createElement('p')
            phone.innerHTML = "Номер телефона: " + response.data[0]["phone"];
            resp.appendChild(phone);

            let pbl2 = document.createElement('p');
            if (response.data[0]["birthday"] == null) {
                pbl2.innerHTML = "День рождения: не указано"
            } else {
                pbl2.innerHTML = "День рождения: " + birth2
            }
            resp.appendChild(pbl2);
        })
}

//Обновление данных о пользователе на сервере
async function loadData() {
    await fetch(base_URL + "api/manage", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        },
        body: JSON.stringify({
            id: id,
            first_name: this.first_name.value,
            last_name: this.last_name.value,
            gender: this.gender.value,
            birthday: this.birthday.value
        })
    })
        .then(json)
        .then(setTimeout(
            function () {
                window.location.href = '/profile.html';
            }, 1000)
        )
}

//Загрузка аватара на сервер и обновление path в бд
async function loadavatar() {
    await fetch(base_URL + "api/avatarupload", {
        method: "POST",
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        },
        body: new FormData(avaform)
    })
        .then(json)
        .then(function (response) {
            let path = response.path;
            if (path.length > 3) {
                fetch(base_URL + "api/updateprofile", {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        'Authorization': 'Bearer ' + localStorage.getItem('token')
                    },
                    body: JSON.stringify({
                        avatar: path,
                        id: id,
                    })
                })
                    .then(setTimeout(
                        function () {
                            window.location.href = '/profile.html';
                        }, 1000)
                    )
            }
        })
}