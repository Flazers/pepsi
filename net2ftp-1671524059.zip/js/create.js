onloads()
//Создание поста
async function create() {
    await fetch(base_URL + "api/create", {
        method: "POST",
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        },
        body: new FormData(create_post),
    })
        .then(function (response) {
            if (response.ok) {
                document.location.href = "/"
            } else {
                let resp = document.getElementById('response')
                let div = document.createElement('div');
                div.innerHTML = 'Пост не отправлен'
                div.id = 'block'
                resp.appendChild(div);
                setTimeout(function () {
                    let resp = document.getElementById('response')
                    let block = document.getElementById('block')
                    resp.removeChild(block)
                }, 1500);
            }
        })
        .then(json)
}