//РЕГИСТРАЦИЯ
async function register() {
    await fetch(base_URL + 'api/register', {
        method: 'POST',
        body: new FormData(authform),
    })
        .then(json)
        .then(function (response) {
            if (response.error !== undefined) {
                let data_er = response.error.errors;
                if (data_er.user_id !== undefined) {
                    if (data_er.user_id.length == 2) {
                        let input = document.getElementById('user_id');
                        input.className = 'invalidclass';

                        let error = document.querySelector('div#user_id_check');
                        let div = document.createElement('div');
                        div.id = 'block';
                        div.innerHTML = 'Поле не может быть пустым';
                        error.appendChild(div);
                        setTimeout(function () {
                            let block = document.getElementById('block');
                            error.removeChild(block);
                        }, 2000);
                    } else if (data_er.user_id.length == 1) {
                        let input = document.getElementById('user_id');
                        input.className = 'invalidclass';

                        let error = document.querySelector('div#user_id_check');
                        let div = document.createElement('div');
                        div.id = 'block';
                        div.innerHTML = 'Данный никнейм занят';
                        error.appendChild(div);
                        setTimeout(function () {
                            let block = document.getElementById('block');
                            error.removeChild(block);
                        }, 2000);
                    }
                } if (data_er.phone !== undefined) {
                    if (data_er.phone.length == 2) {
                        let input = document.getElementById('phone');
                        input.className = 'invalidclass';

                        let error = document.querySelector('div#phone_check');
                        let div = document.createElement('div');
                        div.id = 'block';
                        div.innerHTML = 'Поле не может быть пустым';
                        error.appendChild(div);
                        setTimeout(function () {
                            let block = document.getElementById('block');
                            error.removeChild(block);
                        }, 2000);
                    } else if (data_er.phone.length == 1) {
                        let input = document.getElementById('phone');
                        input.className = 'invalidclass';

                        let error = document.querySelector('div#phone_check');
                        let div = document.createElement('div');
                        div.id = 'block';
                        div.innerHTML = 'Данный номер телефона занят';
                        error.appendChild(div);
                        setTimeout(function () {
                            let block = document.getElementById('block');
                            error.removeChild(block);
                        }, 2000);
                    }
                } if (data_er.password !== undefined) {
                    let input = document.getElementById('password');
                    input.className = 'invalidclass';

                    let error = document.querySelector('div#password_check');
                    let div = document.createElement('div');
                    div.id = 'block';
                    div.innerHTML = 'Поле не может быть пустым';
                    error.appendChild(div);
                    setTimeout(function () {
                        let block = document.getElementById('block');
                        error.removeChild(block);
                    }, 2000);
                }
            } else if (response.data !== undefined) {
                window.location.href = '/auth.html';
            }
        })
}

//ВХОД
async function auth() {
    await fetch(base_URL + 'api/login', {
        method: 'POST',
        body: new FormData(authform)
    })
        .then(json)
        .then(function (response) {
            if (!response.error) {
                localStorage.setItem('user', response.data.user);
                localStorage.setItem('id', response.data.id);
                localStorage.setItem('token', response.data.api_token)
                window.location.href = '/';
            }
        })
}